DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_fname` varchar(45) NOT NULL,
  `accounts_lname` varchar(45) NOT NULL,
  `accounts_username` varchar(45) NOT NULL,
  `accounts_password` varchar(255) NOT NULL,
  `accounts_type` varchar(45) NOT NULL,
  `accounts_email` varchar(45) NOT NULL,
  `accounts_image` longblob,
  PRIMARY KEY (`accounts_id`),
  UNIQUE KEY `accounts_id_UNIQUE` (`accounts_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
LOCK TABLES `accounts` WRITE;
INSERT INTO `accounts` VALUES (1,'Ray','Servidad','rayServidad','$2y$10$v32L0yQoJ.DhoO4ZtpkC9uXz4TwzWP9XRZ4IU2tzH87V2oovneazi','Admin','benzservidad13@gmail.com',NULL),(2,'Jam','Rocafort','jamRocafort','$2y$10$3mxE/Cc2AgSIIvWsj8RZROlETQKAqRr4VO12W59J5PucweQeS0XGu','MatEng','jamspica@gmail.com',NULL),(3,'Theo','Rivera','theoRivera','$2y$10$pkmXS85Hu.Xmq6KW9lQVZui3fM4Yk0TeQbfKauiesMj6pjlHt3NY2','ViewOnly','theorivera@gmail.com',NULL);
UNLOCK TABLES;
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `projects_id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_name` varchar(45) NOT NULL,
  `projects_address` varchar(45) NOT NULL,
  `projects_sdate` date NOT NULL,
  `projects_edate` date NOT NULL,
  `projects_status` varchar(45) NOT NULL,
  PRIMARY KEY (`projects_id`),
  UNIQUE KEY `projects_id_UNIQUE` (`projects_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
LOCK TABLES `projects` WRITE;
INSERT INTO `projects` VALUES (1,'SM Baguio Expansion','Luneta Hill, Baguio City','2017-07-12','2019-03-17','open'),(2,'SOGO Hotel Baguio','Engineers Hill, Baguio City','2018-03-06','2020-12-13','closed');
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_name` varchar(45) NOT NULL,
  PRIMARY KEY (`categories_id`),
  UNIQUE KEY `categories_id_UNIQUE` (`categories_id`),
  UNIQUE KEY `categories_name_UNIQUE` (`categories_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
LOCK TABLES `categories` WRITE;
INSERT INTO `categories` VALUES (4,'Blades'),(9,'Consumables'),(2,'Electrical'),(1,'Formworks'),(10,'Heavy Equipment'),(5,'Lubricants'),(7,'Office'),(11,'Others'),(3,'Plumbing'),(6,'Table Forms'),(8,'Tower Crane');
UNLOCK TABLES;
DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials` (
  `mat_id` int(11) NOT NULL AUTO_INCREMENT,
  `mat_name` varchar(45) NOT NULL,
  `mat_prevStock` varchar(45) DEFAULT NULL,
  `mat_project` int(11) NOT NULL,
  `mat_unit` varchar(45) NOT NULL,
  `mat_categ` int(11) NOT NULL,
  `mat_notif` int(11) NOT NULL,
  PRIMARY KEY (`mat_id`),
  UNIQUE KEY `mat_id_UNIQUE` (`mat_id`),
  UNIQUE KEY `mat_name_UNIQUE` (`mat_name`),
  KEY `categories_idx` (`mat_categ`),
  KEY `projects_idx` (`mat_project`),
  KEY `categories_id` (`mat_categ`),
  CONSTRAINT `categories` FOREIGN KEY (`mat_categ`) REFERENCES `categories` (`categories_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `projects` FOREIGN KEY (`mat_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
LOCK TABLES `materials` WRITE;
INSERT INTO `materials` VALUES (1,'A-clamp Assembly','42',1,'pcs',1,50),(2,'Bolt & Nut 1/2x4 w/ washer','100',1,'pcs',1,250),(3,'Grounding Wire 60mmsg','60',2,'mtrs',2,75),(4,'THHN Wire 3.5mm2','1',2,'rolls',2,2),(5,'Bushing 3\"','3',1,'pcs',3,2),(6,'PVC Pipe 3\" x 3m','1',2,'pcs',3,4),(7,'Cup Brush 4\"','0',1,'pcs',4,60),(8,'Cutting Disc 4\"','70',1,'pcs',4,100),(9,'Beam Hanger','249',2,'pcs',6,500),(10,'Table Form T1 (3.353 x 6.990)','10',2,'pcs',6,20),(11,'Christmas Gift','1',1,'pcs',11,5),(12,'Anchor Bolt w/ Nut 20mm x 50mm','304',1,'pcs',11,350);
UNLOCK TABLES;
DROP TABLE IF EXISTS `hauling`;
CREATE TABLE `hauling` (
  `hauling_id` int(11) NOT NULL AUTO_INCREMENT,
  `hauling_no` int(11) NOT NULL,
  `hauling_date` date NOT NULL,
  `hauling_deliverTo` varchar(45) NOT NULL,
  `hauling_hauledFrom` varchar(45) NOT NULL,
  `hauling_quantity` int(11) NOT NULL,
  `hauling_unit` int(11) NOT NULL,
  `hauling_matname` varchar(45) NOT NULL,
  `hauling_hauledBy` varchar(45) NOT NULL,
  `hauling_warehouseman` varchar(45) NOT NULL,
  `hauling_approvedBy` varchar(45) NOT NULL,
  `hauling_truckDetalisType` varchar(45) NOT NULL,
  `hauling_truckDetailsPlateNo` varchar(45) NOT NULL,
  `hauling_truckDetailsPo` varchar(45) NOT NULL,
  `hauling_truckDetailsHaulerDr` varchar(45) NOT NULL,
  PRIMARY KEY (`hauling_id`),
  UNIQUE KEY `hauling_id_UNIQUE` (`hauling_id`),
  UNIQUE KEY `hauling_no_UNIQUE` (`hauling_no`),
  CONSTRAINT `haulmat` FOREIGN KEY (`hauling_id`) REFERENCES `materials` (`mat_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
LOCK TABLES `hauling` WRITE;
INSERT INTO `hauling` VALUES (1,1,'2019-03-03','Rimando Inc.','NGCB Expansion Site',250,1,'Beam Hanger','Caryl Oficiar','Vincent Ibalio','Jam Rocafort','HOWO Dump Truck','QWE 1990','171036','1234');
UNLOCK TABLES;
DROP TABLE IF EXISTS `stockcard`;
CREATE TABLE `stockcard` (
  `stockcard_id` int(11) NOT NULL AUTO_INCREMENT,
  `stockcard_quantity` int(11) NOT NULL,
  `stockcard_totalDelivered` int(11) NOT NULL,
  `stockcard_totalPulledOut` int(11) NOT NULL,
  `stockcard_matName` int(11) DEFAULT NULL,
  PRIMARY KEY (`stockcard_id`),
  UNIQUE KEY `stockcard_id_UNIQUE` (`stockcard_id`),
  KEY `matName_idx` (`stockcard_matName`),
  CONSTRAINT `matName` FOREIGN KEY (`stockcard_matName`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `matStock` FOREIGN KEY (`stockcard_id`) REFERENCES `materials` (`mat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
LOCK TABLES `stockcard` WRITE;
INSERT INTO `stockcard` VALUES (1,350,350,20,1),(2,69,69,10,2),(3,55,55,30,3),(4,40,40,12,4),(5,500,500,350,5),(6,34,34,10,6),(7,200,200,55,7),(8,650,650,200,8),(9,3,3,1,9),(10,45,45,20,10),(11,10,10,5,11),(12,450,450,300,12);
UNLOCK TABLES;
DROP TABLE IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) NOT NULL AUTO_INCREMENT,
  `todo_date` date NOT NULL,
  `todo_task` varchar(45) NOT NULL,
  `todo_status` varchar(45) NOT NULL,
  PRIMARY KEY (`todo_id`),
  UNIQUE KEY `todo_id_UNIQUE` (`todo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
LOCK TABLES `todo` WRITE;
INSERT INTO `todo` VALUES (1,'2019-05-19','Delivery day','done'),(2,'2019-01-21','Delivery day','in progress'),(3,'2019-08-05','Delivery day','in progress'),(4,'2019-07-08','Delivery day','done');
UNLOCK TABLES;
DROP TABLE IF EXISTS `deliveredin`;
CREATE TABLE `deliveredin` (
  `delivered_id` int(11) NOT NULL AUTO_INCREMENT,
  `delivered_date` date NOT NULL,
  `delivered_quantity` int(11) NOT NULL,
  `delivered_unit` int(11) NOT NULL,
  `suppliedBy` varchar(45) NOT NULL,
  PRIMARY KEY (`delivered_id`),
  UNIQUE KEY `delivered_id_UNIQUE` (`delivered_id`),
  KEY `deliveredunit_idx` (`delivered_unit`),
  CONSTRAINT `deliveredstockcard` FOREIGN KEY (`delivered_id`) REFERENCES `stockcard` (`stockcard_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `deliveredunit` FOREIGN KEY (`delivered_unit`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
LOCK TABLES `deliveredin` WRITE;
INSERT INTO `deliveredin` VALUES (1,'2019-03-05',350,1,'Rimando Inc.'),(2,'2019-01-01',69,2,'Dela Peña Inc.'),(3,'2019-02-13',95,1,'Vinluan Corp.');
UNLOCK TABLES;
DROP TABLE IF EXISTS `usagein`;
CREATE TABLE `usagein` (
  `usage_id` int(11) NOT NULL AUTO_INCREMENT,
  `usage_date` date NOT NULL,
  `usage_quantity` int(11) NOT NULL,
  `usage_unit` int(11) NOT NULL,
  `pulledOutBy` varchar(45) NOT NULL,
  `usage_areaOfUsage` varchar(45) NOT NULL,
  PRIMARY KEY (`usage_id`),
  UNIQUE KEY `usage_id_UNIQUE` (`usage_id`),
  KEY `usageunit_idx` (`usage_unit`),
  CONSTRAINT `usagestockcard` FOREIGN KEY (`usage_id`) REFERENCES `stockcard` (`stockcard_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usageunit` FOREIGN KEY (`usage_unit`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
LOCK TABLES `usagein` WRITE;
INSERT INTO `usagein` VALUES (1,'2018-11-23',3,1,'Laroza','SM B-up'),(2,'2018-11-24',45,2,'Dulce','PH-2'),(3,'2018-11-24',17,1,'Bisaya','PH-2 B-3'),(4,'2018-11-24',3,1,'Vinaya','Foot'),(5,'2018-11-24',59,2,'Pepito','B-up'),(6,'2018-11-24',69,1,'Pepito','PH-1 B-up');
UNLOCK TABLES;