DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_fname` varchar(45) NOT NULL,
  `accounts_lname` varchar(45) NOT NULL,
  `accounts_username` varchar(45) NOT NULL,
  `accounts_password` varchar(255) NOT NULL,
  `accounts_type` varchar(45) NOT NULL,
  PRIMARY KEY (`accounts_id`),
  UNIQUE KEY `accounts_id_UNIQUE` (`accounts_id`),
  UNIQUE KEY `accounts_username_UNIQUE` (`accounts_username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
LOCK TABLES `accounts` WRITE;
INSERT INTO `accounts` VALUES (1,'admin','admin','admin','$2y$10$GgzdZsuliUUauic.JuB6.eabcLQCblxPZAfbsYWJn8GWvh9BXrz8G','Admin'),(2,'Harold','Vinluan','h_vinluan','$2y$10$KIcnceeexxUQX3PYNPN7gOYZCxRKkToc08oU6CLdYML80nHjbYGwm','View Only'),(3,'Mikka','Tuguinay','mikka_tuguinay19','$2y$10$TnHEJm9GItxg.zqtq2dSQetzGEkgdauMAtuMklAnfXloTN10J6.hS','Materials Engineer');
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `categories_id` int(11) NOT NULL DEFAULT '1',
  `categories_name` varchar(45) NOT NULL,
  PRIMARY KEY (`categories_id`),
  UNIQUE KEY `categories_id_UNIQUE` (`categories_id`),
  UNIQUE KEY `categories_name_UNIQUE` (`categories_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `categories` WRITE;
INSERT INTO `categories` VALUES (2,'Electrical'),(1,'Formworks'),(3,'Plumbing');
UNLOCK TABLES;
DROP TABLE IF EXISTS `hauling`;
CREATE TABLE `hauling` (
  `hauling_id` int(11) NOT NULL AUTO_INCREMENT,
  `hauling_no` varchar(45) NOT NULL,
  `hauling_date` date NOT NULL,
  `hauling_deliverTo` varchar(45) NOT NULL,
  `hauling_hauledFrom` varchar(45) NOT NULL,
  `hauling_quantity` varchar(45) DEFAULT NULL,
  `hauling_unit` varchar(45) DEFAULT NULL,
  `hauling_articles` varchar(70) DEFAULT NULL,
  `hauling_hauledBy` varchar(45) DEFAULT NULL,
  `hauling_warehouseman` varchar(45) DEFAULT NULL,
  `hauling_approvedBy` varchar(45) DEFAULT NULL,
  `hauling_truckDetailsType` varchar(45) DEFAULT NULL,
  `hauling_truckDetailsPlateNo` varchar(45) DEFAULT NULL,
  `hauling_truckDetailsPO` varchar(45) DEFAULT NULL,
  `hauling_truckDetailsHaulerDR` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`hauling_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `hauling` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `materials`;
CREATE TABLE `materials` (
  `materials_id` int(11) NOT NULL AUTO_INCREMENT,
  `materials_name` varchar(45) NOT NULL,
  `mat_prevStock` int(11) DEFAULT NULL,
  `mat_deliveredMat` int(11) DEFAULT NULL,
  `mat_matPullOut` int(11) DEFAULT NULL,
  `mat_totalMatDelivered` int(11) DEFAULT NULL,
  `mat_matOnSite` int(11) DEFAULT NULL,
  `mat_project` varchar(100) NOT NULL,
  `mat_quantifier` varchar(45) NOT NULL,
  `mat_categ` varchar(50) NOT NULL,
  `mat_notif` int(11) DEFAULT NULL,
  PRIMARY KEY (`materials_id`),
  UNIQUE KEY `materials_id_UNIQUE` (`materials_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
LOCK TABLES `materials` WRITE;
INSERT INTO `materials` VALUES (1,'A-Clamp Assymbly',42,0,0,42,42,'SM Baguio Expansion','pcs','Formworks',NULL),(2,'Bolt & Nut 1/2x4 w/ washer',100,200,0,300,300,'SOGO Hotel Baguio','pcs','Formworks',NULL),(3,'Grounding Wire 60mmsg',60,0,0,60,60,'SM Baguio Expansion Site','mtrs','Electrical',NULL),(4,'THHN Wire 3.5mm2',1,2,0,3,3,'SOGO Hotel Baguio','rolls','Electrical',NULL),(5,'Bushing 3\"',3,0,0,3,3,'SOGO Hotel Baguio','pcs','Plumbing',NULL),(6,'PVC Pipe 3\" x 3m',1,0,0,1,1,'SM Baguio Expansion Site','pcs','Plumbing',NULL),(7,'Cup Brush 4\"',0,50,0,50,50,'SOGO Hotel Baguio','pcs','Blades',NULL),(8,'Cutting Disc 4\"',70,50,0,120,120,'SM Baguio Expansion Site','pcs','Blades',NULL),(9,'Beam Hanger',249,627,0,876,876,'SM Baguio Expansion Site','pcs','Tableforms',NULL),(10,'Table Form T1 (3.353 x 6.990)',10,13,0,23,23,'SOGO Hotel','pcs','Tableforms',NULL),(11,'Christmas Gift',1,0,0,1,1,'SOGO Hotel','box','Others',NULL),(12,'Anchor Bolt w/ Nut 20mm x 50mm',304,0,0,304,304,'SM Baguio Expansion Site','pcs','Others',NULL);
UNLOCK TABLES;
DROP TABLE IF EXISTS `projects`;
CREATE TABLE `projects` (
  `projects_id` int(11) NOT NULL DEFAULT '1',
  `projects_name` varchar(75) NOT NULL,
  `projects_address` varchar(100) NOT NULL,
  `projects_sdate` date NOT NULL,
  `projects_edate` date NOT NULL,
  `projects_status` varchar(45) NOT NULL,
  PRIMARY KEY (`projects_id`),
  UNIQUE KEY `projects_id_UNIQUE` (`projects_id`),
  UNIQUE KEY `projects_name_UNIQUE` (`projects_name`),
  UNIQUE KEY `projecst_address_UNIQUE` (`projects_address`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES `projects` WRITE;
INSERT INTO `projects` VALUES (1,'NGCB Expansion Site','Luneta Hill, Baguio City','2017-07-12','2019-03-17','open'),(2,'SOGO Hotel Baguio','Engineers Hill, Baguio City','2018-03-06','2020-12-13','closed');
UNLOCK TABLES;
DROP TABLE IF EXISTS `stockcards_deliveredin`;
CREATE TABLE `stockcards_deliveredin` (
  `stockCards_id` int(11) NOT NULL AUTO_INCREMENT,
  `stockCards_date` date NOT NULL,
  `stockCards_quantity` int(11) NOT NULL,
  `stockCards_unit` varchar(45) NOT NULL,
  `stockCards_suppliedBy` varchar(50) NOT NULL,
  PRIMARY KEY (`stockCards_id`),
  UNIQUE KEY `idstockCards_id_UNIQUE` (`stockCards_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
LOCK TABLES `stockcards_deliveredin` WRITE;
INSERT INTO `stockcards_deliveredin` VALUES (1,'2018-10-15',350,'pcs','Rimando Inc.'),(2,'2019-02-10',69,'set','Dela Peña Inc.');
UNLOCK TABLES;
DROP TABLE IF EXISTS `stockcards_usagein`;
CREATE TABLE `stockcards_usagein` (
  `stockCard_id` int(11) NOT NULL AUTO_INCREMENT,
  `stockCard_date` date NOT NULL,
  `stockCard_quantity` int(11) NOT NULL,
  `stockCard_unit` varchar(45) NOT NULL,
  `stockCards_PulledOutBy` varchar(45) NOT NULL,
  `stockCards_AreaOfUsage` varchar(45) NOT NULL,
  PRIMARY KEY (`stockCard_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
LOCK TABLES `stockcards_usagein` WRITE;
INSERT INTO `stockcards_usagein` VALUES (1,'2018-11-23',3,'pcs','Laroza','SM B-up'),(2,'2018-11-24',45,'pcs','Dulce','PH-2'),(3,'2018-11-24',17,'pcs','Bisaya','PH-2 B-3'),(4,'2018-11-24',3,'pcs','Vinaya','Foot'),(5,'2018-11-24',59,'pcs','Pepito','B-up'),(6,'2018-11-24',69,'pcs','Pepito','PH-1 B-up');
UNLOCK TABLES;
DROP TABLE IF EXISTS `todo`;
CREATE TABLE `todo` (
  `todo_id` int(11) NOT NULL AUTO_INCREMENT,
  `todo_date` date NOT NULL,
  `todo_task` varchar(100) NOT NULL,
  `todo_status` varchar(45) NOT NULL,
  PRIMARY KEY (`todo_id`),
  UNIQUE KEY `todo_id_UNIQUE` (`todo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
LOCK TABLES `todo` WRITE;
UNLOCK TABLES;
