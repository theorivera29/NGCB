-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 28, 2019 at 04:00 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ngcb`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE IF NOT EXISTS `accounts` (
  `accounts_id` int(11) NOT NULL AUTO_INCREMENT,
  `accounts_fname` varchar(45) NOT NULL,
  `accounts_lname` varchar(45) NOT NULL,
  `accounts_username` varchar(45) NOT NULL,
  `accounts_password` varchar(255) NOT NULL,
  `accounts_type` varchar(45) NOT NULL,
  `accounts_email` varchar(45) NOT NULL,
  `accounts_deletable` varchar(45) NOT NULL,
  `accounts_status` varchar(45) NOT NULL,
  PRIMARY KEY (`accounts_id`),
  UNIQUE KEY `accounts_id_UNIQUE` (`accounts_id`),
  UNIQUE KEY `accounts_username_UNIQUE` (`accounts_username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`accounts_id`, `accounts_fname`, `accounts_lname`, `accounts_username`, `accounts_password`, `accounts_type`, `accounts_email`, `accounts_deletable`, `accounts_status`) VALUES
(1, 'admin', 'admin', 'admin', '$2y$10$1wlaSq5G8Fvv4WydcAF4L.H6wCVkO.p5J3GdtXWEHqGWRDlXZPEaG', 'Admin', 'benzservidad13@gmail.com', 'no', 'active'),
(2, 'materials_engineer', 'materials_engineer', 'materials_engineer', '$2y$10$5qNGMvsm7wEwUCdF2v5pYeadU5woLEhIP9gRreHyHl350N0JuFwie', 'MatEng', 'jamspica@gmail.com', 'no', 'active'),
(3, 'view_only', 'view_only', 'view_only', '$2y$10$IBUx9N2bKy.mObs8ZquGPeD/RqQlP/8toMeOfQW0EOxd8dMiJcfNm', 'ViewOnly', 'theorivera@gmail.com', 'no', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `categories_name` varchar(45) NOT NULL,
  `categories_project` int(11) NOT NULL,
  PRIMARY KEY (`categories_id`),
  UNIQUE KEY `categories_id_UNIQUE` (`categories_id`),
  UNIQUE KEY `categories_name_UNIQUE` (`categories_name`),
  KEY `cat_projects_idx` (`categories_project`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `deliveredin`
--

DROP TABLE IF EXISTS `deliveredin`;
CREATE TABLE IF NOT EXISTS `deliveredin` (
  `delivered_id` int(11) NOT NULL AUTO_INCREMENT,
  `delivered_date` date NOT NULL,
  `delivered_quantity` int(11) NOT NULL,
  `delivered_unit` int(11) NOT NULL,
  `suppliedBy` varchar(45) NOT NULL,
  `delivered_matName` int(11) NOT NULL,
  PRIMARY KEY (`delivered_id`),
  UNIQUE KEY `delivered_id_UNIQUE` (`delivered_id`),
  KEY `deliveredmat_idx` (`delivered_matName`),
  KEY `deliveredunit_idx` (`delivered_unit`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hauling`
--

DROP TABLE IF EXISTS `hauling`;
CREATE TABLE IF NOT EXISTS `hauling` (
  `hauling_id` int(11) NOT NULL AUTO_INCREMENT,
  `hauling_no` int(11) NOT NULL,
  `hauling_date` date NOT NULL,
  `hauling_deliverTo` varchar(45) NOT NULL,
  `hauling_hauledFrom` varchar(45) NOT NULL,
  `hauling_quantity` int(11) NOT NULL,
  `hauling_unit` int(11) NOT NULL,
  `hauling_matname` int(11) NOT NULL,
  `hauling_hauledBy` varchar(45) NOT NULL,
  `hauling_requestedBy` varchar(45) NOT NULL,
  `hauling_warehouseman` varchar(45) NOT NULL,
  `hauling_approvedBy` varchar(45) NOT NULL,
  `hauling_truckDetailsType` varchar(45) NOT NULL,
  `hauling_truckDetailsPlateNo` varchar(45) NOT NULL,
  `hauling_truckDetailsPo` varchar(45) NOT NULL,
  `hauling_truckDetailsHaulerDr` varchar(45) NOT NULL,
  PRIMARY KEY (`hauling_id`),
  UNIQUE KEY `hauling_id_UNIQUE` (`hauling_id`),
  KEY `haulingmat_idx` (`hauling_matname`),
  KEY `haulingunit_idx` (`hauling_unit`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
CREATE TABLE IF NOT EXISTS `logs` (
  `logs_id` int(11) NOT NULL AUTO_INCREMENT,
  `logs_datetime` datetime NOT NULL,
  `logs_activity` varchar(45) NOT NULL,
  `logs_logsOf` int(11) NOT NULL,
  PRIMARY KEY (`logs_id`),
  UNIQUE KEY `logs_id_UNIQUE` (`logs_id`),
  KEY `logsmateng_idx` (`logs_logsOf`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
CREATE TABLE IF NOT EXISTS `materials` (
  `mat_id` int(11) NOT NULL AUTO_INCREMENT,
  `mat_name` varchar(45) NOT NULL,
  `mat_prevStock` varchar(45) DEFAULT NULL,
  `mat_project` int(11) NOT NULL,
  `mat_unit` int(11) NOT NULL,
  `mat_categ` int(11) NOT NULL,
  `mat_notif` int(11) NOT NULL,
  `currentQuantity` int(11) NOT NULL,
  PRIMARY KEY (`mat_id`),
  UNIQUE KEY `mat_id_UNIQUE` (`mat_id`),
  UNIQUE KEY `mat_name_UNIQUE` (`mat_name`),
  KEY `categories_idx` (`mat_categ`),
  KEY `projects_idx` (`mat_project`),
  KEY `categories_id` (`mat_categ`),
  KEY `matunit_idx` (`mat_unit`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `projacc`
--

DROP TABLE IF EXISTS `projacc`;
CREATE TABLE IF NOT EXISTS `projacc` (
  `projacc_id` int(11) NOT NULL AUTO_INCREMENT,
  `projacc_project` int(11) NOT NULL,
  `projacc_mateng` int(11) NOT NULL,
  PRIMARY KEY (`projacc_id`),
  KEY `project_idx` (`projacc_project`),
  KEY `mateng_idx` (`projacc_mateng`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `projects_id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_name` varchar(45) NOT NULL,
  `projects_address` varchar(45) NOT NULL,
  `projects_sdate` date NOT NULL,
  `projects_edate` date NOT NULL,
  `projects_status` varchar(45) NOT NULL,
  PRIMARY KEY (`projects_id`),
  UNIQUE KEY `projects_id_UNIQUE` (`projects_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
CREATE TABLE IF NOT EXISTS `request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `req_username` int(11) NOT NULL,
  `req_date` date NOT NULL,
  PRIMARY KEY (`req_id`),
  UNIQUE KEY `req_id_UNIQUE` (`req_id`),
  KEY `requsername_idx` (`req_username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `todo`
--

DROP TABLE IF EXISTS `todo`;
CREATE TABLE IF NOT EXISTS `todo` (
  `todo_id` int(11) NOT NULL AUTO_INCREMENT,
  `todo_date` date NOT NULL,
  `todo_task` varchar(50) NOT NULL,
  `todo_status` varchar(45) NOT NULL,
  `todoOf` int(11) NOT NULL,
  PRIMARY KEY (`todo_id`),
  UNIQUE KEY `todo_id_UNIQUE` (`todo_id`),
  KEY `todomateng_idx` (`todoOf`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
CREATE TABLE IF NOT EXISTS `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(45) NOT NULL,
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `unit_id_UNIQUE` (`unit_id`),
  UNIQUE KEY `unit_name_UNIQUE` (`unit_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usagein`
--

DROP TABLE IF EXISTS `usagein`;
CREATE TABLE IF NOT EXISTS `usagein` (
  `usage_id` int(11) NOT NULL AUTO_INCREMENT,
  `usage_date` date NOT NULL,
  `usage_quantity` int(11) NOT NULL,
  `usage_unit` int(11) NOT NULL,
  `pulledOutBy` varchar(45) NOT NULL,
  `usage_areaOfUsage` varchar(45) NOT NULL,
  `usage_matname` int(11) NOT NULL,
  PRIMARY KEY (`usage_id`),
  UNIQUE KEY `usage_id_UNIQUE` (`usage_id`),
  KEY `usageunit_idx` (`usage_unit`),
  KEY `usagemat_idx` (`usage_matname`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `cat_projects` FOREIGN KEY (`categories_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `deliveredin`
--
ALTER TABLE `deliveredin`
  ADD CONSTRAINT `deliveredmat` FOREIGN KEY (`delivered_matName`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `deliveredunit` FOREIGN KEY (`delivered_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hauling`
--
ALTER TABLE `hauling`
  ADD CONSTRAINT `haulingmat` FOREIGN KEY (`hauling_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `haulingunit` FOREIGN KEY (`hauling_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logsmateng` FOREIGN KEY (`logs_logsOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `materials`
--
ALTER TABLE `materials`
  ADD CONSTRAINT `categories` FOREIGN KEY (`mat_categ`) REFERENCES `categories` (`categories_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `matunit` FOREIGN KEY (`mat_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `projects` FOREIGN KEY (`mat_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `projacc`
--
ALTER TABLE `projacc`
  ADD CONSTRAINT `mateng` FOREIGN KEY (`projacc_mateng`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `project` FOREIGN KEY (`projacc_project`) REFERENCES `projects` (`projects_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `request`
--
ALTER TABLE `request`
  ADD CONSTRAINT `requsername` FOREIGN KEY (`req_username`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `todo`
--
ALTER TABLE `todo`
  ADD CONSTRAINT `todomateng` FOREIGN KEY (`todoOf`) REFERENCES `accounts` (`accounts_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `usagein`
--
ALTER TABLE `usagein`
  ADD CONSTRAINT `usagemat` FOREIGN KEY (`usage_matname`) REFERENCES `materials` (`mat_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `usageunit` FOREIGN KEY (`usage_unit`) REFERENCES `unit` (`unit_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
